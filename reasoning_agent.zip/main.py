import os
from textwrap import dedent
from typing import Any

# Optional: AgentProbe SDK for rich trace timelines
try:
    from agentprobe_sdk import traced_agent
except ImportError:
    def traced_agent(name: str):
        def decorator(f):
            return f
        return decorator

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

api_key = os.getenv("NEBIUS_API_KEY", "").strip()
USE_MOCK = not api_key or api_key in ("mock", "none", "")

reasoning_agent = None
if not USE_MOCK:
    # Only import agno when a real API key is present
    try:
        from agno.agent import Agent
        from agno.models.nebius import Nebius
        from agno.tools.reasoning import ReasoningTools

        reasoning_agent = Agent(
            model=Nebius(
                id="meta-llama/Llama-3.3-70B-Instruct",
                api_key=api_key,
            ),
            tools=[ReasoningTools(add_instructions=True)],
            instructions=dedent("""\
                You are an expert financial advisor with a focus on investment strategies.
            """),
            add_datetime_to_instructions=True,
            markdown=True,
        )
    except Exception:
        USE_MOCK = True


def generate_mock_reasoning(user_input: str) -> str:
    query = user_input.lower()
    if any(w in query for w in ["moderate", "risk", "invest", "strategy", "portfolio"]):
        return (
            "### Investment Strategy — Moderate Risk Profile\n\n"
            "**Recommended Allocation:**\n"
            "- 40% US Broad Market Index ETF (e.g. VTI)\n"
            "- 20% International Developed Markets ETF\n"
            "- 25% US Treasury / Investment-Grade Bonds\n"
            "- 10% TIPS (Inflation-Protected)\n"
            "- 5%  Money Market / Cash Reserve\n\n"
            "**Key Principles:**\n"
            "- Rebalance semi-annually.\n"
            "- Use tax-advantaged accounts (401k/IRA) first.\n"
            "- Dollar-cost average to reduce timing risk.\n\n"
            "*This is a deterministic mock response for evaluation purposes.*"
        )
    return (
        f"**Financial Advisory Response**\n\n"
        f"Query: *{user_input}*\n\n"
        "Recommendation: Diversify across equities, bonds, and cash equivalents "
        "based on your time horizon and risk tolerance. Consult a licensed advisor "
        "for personalized guidance.\n\n"
        "*Mock response — no API key provided.*"
    )


@traced_agent(name="financial_reasoning_agent")
def run(prompt: str = "", **kwargs: Any) -> dict[str, Any]:
    """AgentProbe entrypoint — text input mode, parameter='prompt'."""
    user_input = str(
        prompt or kwargs.get("input") or kwargs.get("query")
        or "Recommend an investment strategy"
    )

    if not USE_MOCK and reasoning_agent is not None:
        try:
            response = reasoning_agent.run(user_input)
            text = str(response.content) if hasattr(response, "content") else str(response)
        except Exception:
            text = generate_mock_reasoning(user_input)
    else:
        text = generate_mock_reasoning(user_input)

    return {"final_answer": text, "output": text}


if __name__ == "__main__":
    result = run("Recommend an investment strategy for moderate risk tolerance")
    print(result["final_answer"])